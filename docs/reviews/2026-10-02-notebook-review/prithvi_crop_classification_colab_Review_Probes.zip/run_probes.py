"""Review probes for prithvi_crop_classification_colab.ipynb (row 68, Notebook Review Framework v1).

CPU only (CUDA_VISIBLE_DEVICES=-1). No Prithvi weights, no tarball: model cells are exercised with the
repository's own stub model (copied from tests/test_adaptation.py) and synthetic chips (tests/conftest.py).
Every result here is a stand-in observation, labelled as such in results.json.

Usage: python run_probes.py <repo_worktree> <scratch_dir>
"""

from __future__ import annotations

import hashlib
import io
import json
import os
import re
import subprocess
import sys
import time
import traceback
import types
import zipfile
from pathlib import Path

REPO = Path(sys.argv[1]).resolve()
SCRATCH = Path(sys.argv[2]).resolve()
SCRATCH.mkdir(parents=True, exist_ok=True)
NB_PATH = REPO / "tutorials" / "prithvi_crop_classification_colab.ipynb"
results: dict = {"env": {"python": sys.version.split()[0], "CUDA_VISIBLE_DEVICES": os.environ.get("CUDA_VISIBLE_DEVICES")}}
t_start = time.time()


def save():
    (SCRATCH / "results.json").write_text(json.dumps(results, indent=1, default=str), encoding="utf-8")


nb = json.loads(NB_PATH.read_text(encoding="utf-8"))
cells = nb["cells"]
src = ["".join(c["source"]) for c in cells]
markdown = "\n".join(s for c, s in zip(cells, src) if c["cell_type"] == "markdown")
code_idx = [i for i, c in enumerate(cells) if c["cell_type"] == "code"]

# ---- P1 static ------------------------------------------------------------------------------------------
p1: dict = {"n_cells": len(cells), "code_cells": code_idx}
compiled = {}
for i in code_idx:
    try:
        compile(src[i], f"cell{i}", "exec")
        compiled[i] = True
    except SyntaxError as exc:
        compiled[i] = str(exc)
p1["all_code_compiles"] = all(v is True for v in compiled.values())
low = markdown.lower()
p1["guided_markers"] = {k: (k.lower() in low) for k in ("How to use", "Glossary", "Troubleshoot", "Roadmap", "Check your reasoning", "Predict", "audience", "Infrastructure", "What to notice", "conclusion")}
p1["cellView_form_code_cells"] = [i for i in code_idx if cells[i].get("metadata", {}).get("cellView") == "form"]
p1["carried_module_lines"] = {cells[i]["metadata"]["dimer"]["embedded_module"]: src[i].count("\n") + 1 for i in code_idx if cells[i].get("metadata", {}).get("dimer", {}).get("embedded_module")}
p1["image_display_calls"] = sum(len(re.findall(r"plt\.|imshow|display\(|matplotlib", src[i])) for i in code_idx if not cells[i].get("metadata", {}).get("dimer"))
p1["brace_typo_present"] = "{{id, image, label}}" in markdown
p1["markdown_claims_8_tensors"] = re.findall(r"[^.]*\b8 tensors\b[^.]*", markdown)
p1["threshold_or_deployment_in_markdown"] = {"threshold": "threshold" in low, "deployment's": "deployment" in low, "calibrat": "calibrat" in low}
p1["source_id_uses_in_tutorial_cells"] = {i: src[i].count("['source_id']") for i in code_idx if "['source_id']" in src[i]}
p1["region_uses_in_tutorial_cells"] = {i: src[i].count("['region']") for i in code_idx if "['region']" in src[i]}
p1["probe_slice_test_records_1_4"] = "test_records[1:4]" in src[15]
p1["byod_minimum_stated"] = re.findall(r"at least \w+ chips[^.]*", markdown)
p1["metadata_dimer"] = nb["metadata"].get("dimer")
results["P1_static"] = p1
save()

# ---- P2 tooling -----------------------------------------------------------------------------------------
env = dict(os.environ, PYTHONPATH=str(REPO / "src"), PYTHONIOENCODING="utf-8")
p2 = {}
for name, cmd in {
    "build_check": [sys.executable, "tools/build_notebook.py", "--check"],
    "validator": [sys.executable, "tools/validate_release_assets.py"],
    "pytest": [sys.executable, "-m", "pytest", "-q", "-p", "no:cacheprovider", "tests", "-rs"],
}.items():
    r = subprocess.run(cmd, cwd=REPO, env=env, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=500)
    p2[name] = {"exit": r.returncode, "tail": (r.stdout + r.stderr).strip().splitlines()[-3:]}
results["P2_tooling"] = p2
save()

# ---- load carried modules from the notebook cells (exactly what the notebook runs) -----------------------
sys.path.insert(0, str(REPO / "tests"))
import numpy as np  # noqa: E402
import tifffile  # noqa: E402
import torch  # noqa: E402
from conftest import synthetic_chip  # noqa: E402

ns: dict = {"__name__": "__main__"}
for i in code_idx:
    if cells[i].get("metadata", {}).get("dimer", {}).get("embedded_module"):
        exec(compile(src[i], f"cell{i}", "exec"), ns)
PCP = ns["PrithviCropPipeline"]
NUM_CLASSES = ns["NUM_CLASSES"]


class _StubModel(torch.nn.Module):
    """Copied from tests/test_adaptation.py: parameter names follow the vendored layout."""

    def __init__(self) -> None:
        super().__init__()
        self.backbone = torch.nn.Module()
        self.backbone.blocks = torch.nn.ModuleList([torch.nn.Module() for _ in range(6)])
        for block in self.backbone.blocks:
            block.w = torch.nn.Parameter(torch.ones(1))
        self.neck = torch.nn.Module()
        self.neck.scale = torch.nn.Parameter(torch.ones(1))
        self.decode_head = torch.nn.Module()
        self.decode_head.weight = torch.nn.Parameter(torch.zeros(6))
        self.decode_head.bias = torch.nn.Parameter(torch.zeros(NUM_CLASSES))

    def forward(self, x):
        feature = (x[:, :, 0] * self.decode_head.weight[None, :, None, None]).sum(dim=1) * self.neck.scale
        feature = feature * self.backbone.blocks[5].w
        ramp = torch.linspace(-1.0, 1.0, NUM_CLASSES, device=x.device)
        return feature[:, None] * ramp[None, :, None, None] + self.decode_head.bias[None, :, None, None]


def stub_pipe():
    return PCP(model=_StubModel(), device="cpu", weights_dir=SCRATCH / "weights", source="stub")


# Stand-ins for the network-touching calls: a fresh base stub on from_pretrained, a dummy converted record.
PCP.from_pretrained = classmethod(lambda cls, **kw: stub_pipe())
ns["verify_converted"] = lambda *a, **k: {"files": [{"path": "stand-in"}]}


def write_chip_files(n, root: Path, *, seed=0):
    root.mkdir(parents=True, exist_ok=True)
    rows = []
    for k in range(n):
        image, label = synthetic_chip(seed=seed + k)
        tifffile.imwrite(root / f"c{k}.tif", np.rint(image.reshape(18, 224, 224)).astype(np.int16), photometric="minisblack", planarconfig="separate")
        tifffile.imwrite(root / f"c{k}.mask.tif", np.where(label < 0, 0, label + 1).astype(np.uint8), photometric="minisblack")
        rows.append((f"chip{k}", f"c{k}.tif", f"c{k}.mask.tif"))
    return rows


def make_zip(n, path: Path, *, drop_member=None, bad_image=False, no_csv=False):
    stage = SCRATCH / ("stage_" + path.stem)
    rows = write_chip_files(n, stage)
    with zipfile.ZipFile(path, "w") as z:
        if not no_csv:
            z.writestr("pairs.csv", "id,image,label\n" + "".join(f"{a},{b},{c}\n" for a, b, c in rows))
        for _id, image, label in rows:
            if image == drop_member:
                continue
            if bad_image and image == "c0.tif":
                z.writestr(image, b"not a tiff")
            else:
                z.write(stage / image, image)
            z.write(stage / label, label)
    return path


# ---- P3 sample split geometry -----------------------------------------------------------------------------
roles = {}
for name, role, *_ in ns["SAMPLE_RECORDS"]:
    b = ns["chip_block"](name)
    rr, cc = re.match(r"r(\d+)c(\d+)", b).groups(); roles.setdefault(role, set()).add((int(rr), int(cc)))
train_blocks = roles["train"]
adj = {}
for role in ("validation", "test"):
    near = [blk for blk in roles[role] if any(abs(blk[0] - t[0]) <= 1 and abs(blk[1] - t[1]) <= 1 for t in train_blocks)]
    adj[role] = {"blocks": len(roles[role]), "adjacent_to_a_train_block": len(near), "examples": sorted(near)[:4]}
results["P3_split_geometry"] = {"blocks_per_role": {k: len(v) for k, v in roles.items()}, "neighbours": adj}
save()

# ---- P4 BYOD loader + split as Section 4 calls them -------------------------------------------------------
p4 = {}
cases = {f"valid_n{n}": dict(n=n) for n in (4, 5, 6, 7, 8)}
cases.update({"missing_member": dict(n=8, drop_member="c3.tif"), "non_tiff_image": dict(n=8, bad_image=True), "no_pairs_csv": dict(n=8, no_csv=True)})
for name, kw in cases.items():
    z = make_zip(path=SCRATCH / f"{name}.zip", **kw)
    try:
        s = ns["split_dataset"](ns["load_byod_dataset"](z), seed=0)
        p4[name] = {"ok": True, "sizes": {k: len(v) for k, v in s.items()}, "record_keys": sorted(s["test"][0].keys())}
    except BaseException as exc:  # noqa: BLE001
        p4[name] = {"ok": False, "error": f"{type(exc).__name__}: {str(exc)[:160]}"}
results["P4_byod_loader"] = p4
save()

# ---- cell runner -------------------------------------------------------------------------------------------
WORK = SCRATCH / "nbrun"
WORK.mkdir(exist_ok=True)
os.chdir(WORK)


def run_cell(i, subs=None, capture=True):
    code = src[i]
    for old, new in (subs or {}).items():
        assert old in code, (i, old)
        code = code.replace(old, new)
    buf = io.StringIO()
    old_out = sys.stdout
    sys.stdout = buf
    try:
        exec(compile(code, f"cell{i}", "exec"), ns)
        status = {"cell": i, "ok": True}
    except BaseException as exc:  # noqa: BLE001
        status = {"cell": i, "ok": False, "error": f"{type(exc).__name__}: {str(exc)[:200]}", "line": traceback.extract_tb(exc.__traceback__)[-1].line}
    finally:
        sys.stdout = old_out
    status["stdout_tail"] = buf.getvalue().strip().splitlines()[-4:]
    return status


def synthetic_sample():
    out = {"train": [], "validation": [], "test": []}
    k = 0
    for role, n, row in (("train", 8, 0), ("validation", 4, 20), ("test", 4, 40)):
        for j in range(n):
            image, label = synthetic_chip(seed=100 + k)
            out[role].append(ns["check_record"]({"id": f"{role}-{j:03d}", "source_id": f"chip_{row:03d}_{4 * j:03d}", "region": ns["chip_block"](f"chip_{row:03d}_{4 * j:03d}"), "split": role, "image": image, "label": label, "source": "synthetic"}))
            k += 1
    return out


SAMPLE = synthetic_sample()
ns["fetch_sample_dataset"] = lambda **kw: {k: list(v) for k, v in SAMPLE.items()}
ns["WEIGHTS_DIR"] = SCRATCH / "weights"
ns["torch"] = torch
# Section 1 with the documented CI switch (skips only the pip install), and the inline MANIFEST of Section 3
os.environ["DIMER_NOTEBOOK_CI_PREINSTALLED"] = "1"
results["P5_section1_ci_preinstalled"] = run_cell(3)
exec(src[13].split("if (MANIFEST")[0], ns)
FAST = {"EPOCHS = 4": "EPOCHS = 2", "LEARNING_RATE = 1e-5": "LEARNING_RATE = 1e-2"}


def sequence(label, steps):
    out = []
    for i, subs in steps:
        out.append(run_cell(i, subs))
    results[label] = out
    save()
    return out


# P5: default path on synthetic sample + stub (sanity of the cell wiring), then the documented BYOD rerun.
ns["pipe"] = stub_pipe()
true_frozen = stub_pipe().evaluate(SAMPLE["test"])["model"]["mean_iou"]
seq_default = sequence("P5a_default_cells_stub", [(15, None), (17, None), (19, FAST), (21, None), (23, None)])
adapted_after_default = ns["adapted_test"]["model"]["mean_iou"]
kept_val_loss = ns["adapt_result"]["history"][ns["adapt_result"]["best_epoch"]]["val_loss"]

# google.colab stand-in for the upload dialog, returning an 8-chip synthetic BYOD zip
byod_zip = make_zip(8, SCRATCH / "byod8.zip")
google = types.ModuleType("google")
colab = types.ModuleType("google.colab")
colab.files = types.SimpleNamespace(upload=lambda: {"byod8.zip": byod_zip.read_bytes()})
google.colab = colab
sys.modules["google"], sys.modules["google.colab"] = google, colab
BYOD = {"USE_BYOD = False": "USE_BYOD = True"}
seq_byod = sequence("P5b_byod_rerun_from_section4_stub", [(15, BYOD), (17, None), (19, FAST), (21, None), (23, None)])
byod_probe_lines = [l for l in seq_byod[0]["stdout_tail"] if "probe" in l]

# P6: default sample path again from Section 4 (rerun without reset), compare Section 5 'frozen' with true frozen
ns["pipe"] = stub_pipe()
sequence("P6a_default_fresh", [(15, None), (17, None), (19, FAST), (21, None)])
adapted_iou = ns["adapted_test"]["model"]["mean_iou"]
kept = ns["adapt_result"]["history"][ns["adapt_result"]["best_epoch"]]["val_loss"]
true_frozen_val_loss = ns["adapt_result"]["history"][0]["val_loss"]
sequence("P6b_rerun_section4_to_6", [(15, None), (17, None), (19, FAST)])
results["P6_summary"] = {
    "true_frozen_test_mean_iou": true_frozen,
    "adapted_test_mean_iou_after_first_run": adapted_iou,
    "section5_frozen_test_mean_iou_on_rerun": ns["frozen_test"]["model"]["mean_iou"],
    "first_run_epoch0_val_loss_true_frozen": true_frozen_val_loss,
    "first_run_kept_val_loss": kept,
    "rerun_epoch0": {k: ns["adapt_result"]["history"][0].get(k) for k in ("val_loss", "note")},
}
save()

# P7: active learning — TRAINABLE='head+last_block' then back to 'head' (documented optional experiment order)
ns["pipe"] = stub_pipe()
sequence("P7a_default_fresh", [(15, None), (17, None)])
HLB = dict(FAST, **{"TRAINABLE = 'head'": "TRAINABLE = 'head+last_block'"})
sequence("P7b_head_plus_last_block", [(19, HLB), (21, None), (23, None)])
w_after_hlb = float(ns["pipe"].model.backbone.blocks[5].w)
seq7c = sequence("P7c_back_to_head", [(19, FAST), (21, None), (23, None)])
results["P7_summary"] = {"last_block_w_after_head_plus_last_block": w_after_hlb, "last_block_w_in_memory_after_head_run": float(ns["pipe"].model.backbone.blocks[5].w), "artifact_tensors": ns.get("artifact_manifest", {}).get("tensors"), "section8_outcome": seq7c[-1]}
save()

# ---- P8 sample pairs CSV vs extracted names ----------------------------------------------------------------
members = {Path(m).name for _n, _r, img, _b, _s, lab, *_ in ns["SAMPLE_RECORDS"] for m in (img, lab)}
recs = [{"id": "test-000", "source_id": n} for n, r, *_ in ns["SAMPLE_RECORDS"] if r == "test"]
csv_path = ns["write_dataset_csv"]([dict(r, image=np.zeros((3, 6, 224, 224)), label=np.zeros((224, 224), int)) for r in recs], SCRATCH / "pairs.csv")
import csv as _csv  # noqa: E402

rows = list(_csv.DictReader(open(csv_path, encoding="utf-8")))
results["P8_pairs_csv"] = {"rows": len(rows), "image_names_match_extracted_members": all(r["image"] in members for r in rows), "label_names_match_extracted_members": all(r["label"] in members for r in rows), "written_pair_names": ["prithvi_crop_classification_sample_chip.tif", "prithvi_crop_classification_sample_label.tif"], "written_pair_in_csv": any(r["image"].startswith("prithvi") for r in rows)}

results["elapsed_s"] = round(time.time() - t_start, 1)
save()
print(json.dumps({k: results[k] for k in ("P3_split_geometry", "P4_byod_loader", "P6_summary", "P7_summary", "P8_pairs_csv")}, indent=1, default=str))
print("BYOD rerun:", json.dumps(seq_byod, default=str)[:3000])
print("byod probe lines:", byod_probe_lines)
print("default:", [(s["cell"], s["ok"], s.get("error")) for s in seq_default])
print("elapsed", results["elapsed_s"])
